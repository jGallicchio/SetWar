#Homework 03
#Justin Gallicchio
#CSE 2050
from deckofcards import DeckOfCards

class SetDeck(DeckOfCards):
    def __init__(self, cards=None):
         DeckOfCards.__init__(self, cards)
